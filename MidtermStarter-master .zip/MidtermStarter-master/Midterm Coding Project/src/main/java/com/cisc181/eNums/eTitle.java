package com.cisc181.eNums;

public enum eTitle {
MR, MRS, MS
}
